Start utop
Type #use "path_to_parser.ml";;
Type #use "path_to_interpreter.ml";;

Group Members:

Bobby Feliz
Danny Nguyen
Griffin Bjreke
Thomas DeMasse

