Read Me for Tombstones Assignent
Group Members: Thomas DeMasse, Bobby Feliz, Griffin Bjerke

1. Compile with "make test"
2. run executable with "./A4-tests-v3